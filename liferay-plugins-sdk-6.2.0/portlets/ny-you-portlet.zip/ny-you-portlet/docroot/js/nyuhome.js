YUI().use(
'aui-tabview',
function(Y) {
new Y.TabView(
{
srcNode: '#learnTab'
}
).render();
}
); 