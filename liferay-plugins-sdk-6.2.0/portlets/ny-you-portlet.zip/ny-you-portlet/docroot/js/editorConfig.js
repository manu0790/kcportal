CKEDITOR.editorConfig = function(config) {
    config.toolbar = [
                    	['Bold', 'Italic', 'Underline', 'Strike'],
                      	['NumberedList', 'BulletedList'],
                      	['Image', 'Link', 'Unlink', 'Table']
                      ];
    config.fillEmptyBlocks = false;
    config.tabSpaces = 0;
}

