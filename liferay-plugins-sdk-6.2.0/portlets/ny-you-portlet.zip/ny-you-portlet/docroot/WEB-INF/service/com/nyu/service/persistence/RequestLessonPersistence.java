/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.nyu.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.nyu.model.RequestLesson;

/**
 * The persistence interface for the request lesson service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Allwins Rajaiah
 * @see RequestLessonPersistenceImpl
 * @see RequestLessonUtil
 * @generated
 */
public interface RequestLessonPersistence extends BasePersistence<RequestLesson> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link RequestLessonUtil} to access the request lesson persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the request lessons where companyId = &#63;.
	*
	* @param companyId the company ID
	* @return the matching request lessons
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.RequestLesson> findByrequestLessons(
		long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the request lessons where companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.nyu.model.impl.RequestLessonModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param companyId the company ID
	* @param start the lower bound of the range of request lessons
	* @param end the upper bound of the range of request lessons (not inclusive)
	* @return the range of matching request lessons
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.RequestLesson> findByrequestLessons(
		long companyId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the request lessons where companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.nyu.model.impl.RequestLessonModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param companyId the company ID
	* @param start the lower bound of the range of request lessons
	* @param end the upper bound of the range of request lessons (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching request lessons
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.RequestLesson> findByrequestLessons(
		long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first request lesson in the ordered set where companyId = &#63;.
	*
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching request lesson
	* @throws com.nyu.NoSuchRequestLessonException if a matching request lesson could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson findByrequestLessons_First(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchRequestLessonException;

	/**
	* Returns the first request lesson in the ordered set where companyId = &#63;.
	*
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching request lesson, or <code>null</code> if a matching request lesson could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson fetchByrequestLessons_First(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last request lesson in the ordered set where companyId = &#63;.
	*
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching request lesson
	* @throws com.nyu.NoSuchRequestLessonException if a matching request lesson could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson findByrequestLessons_Last(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchRequestLessonException;

	/**
	* Returns the last request lesson in the ordered set where companyId = &#63;.
	*
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching request lesson, or <code>null</code> if a matching request lesson could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson fetchByrequestLessons_Last(
		long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the request lessons before and after the current request lesson in the ordered set where companyId = &#63;.
	*
	* @param requestLessonId the primary key of the current request lesson
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next request lesson
	* @throws com.nyu.NoSuchRequestLessonException if a request lesson with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson[] findByrequestLessons_PrevAndNext(
		long requestLessonId, long companyId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchRequestLessonException;

	/**
	* Removes all the request lessons where companyId = &#63; from the database.
	*
	* @param companyId the company ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByrequestLessons(long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of request lessons where companyId = &#63;.
	*
	* @param companyId the company ID
	* @return the number of matching request lessons
	* @throws SystemException if a system exception occurred
	*/
	public int countByrequestLessons(long companyId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the request lessons where createdDate = &#63;.
	*
	* @param createdDate the created date
	* @return the matching request lessons
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.RequestLesson> findBylessonsBasedOnDate(
		java.util.Date createdDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the request lessons where createdDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.nyu.model.impl.RequestLessonModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param createdDate the created date
	* @param start the lower bound of the range of request lessons
	* @param end the upper bound of the range of request lessons (not inclusive)
	* @return the range of matching request lessons
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.RequestLesson> findBylessonsBasedOnDate(
		java.util.Date createdDate, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the request lessons where createdDate = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.nyu.model.impl.RequestLessonModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param createdDate the created date
	* @param start the lower bound of the range of request lessons
	* @param end the upper bound of the range of request lessons (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching request lessons
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.RequestLesson> findBylessonsBasedOnDate(
		java.util.Date createdDate, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first request lesson in the ordered set where createdDate = &#63;.
	*
	* @param createdDate the created date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching request lesson
	* @throws com.nyu.NoSuchRequestLessonException if a matching request lesson could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson findBylessonsBasedOnDate_First(
		java.util.Date createdDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchRequestLessonException;

	/**
	* Returns the first request lesson in the ordered set where createdDate = &#63;.
	*
	* @param createdDate the created date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching request lesson, or <code>null</code> if a matching request lesson could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson fetchBylessonsBasedOnDate_First(
		java.util.Date createdDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last request lesson in the ordered set where createdDate = &#63;.
	*
	* @param createdDate the created date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching request lesson
	* @throws com.nyu.NoSuchRequestLessonException if a matching request lesson could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson findBylessonsBasedOnDate_Last(
		java.util.Date createdDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchRequestLessonException;

	/**
	* Returns the last request lesson in the ordered set where createdDate = &#63;.
	*
	* @param createdDate the created date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching request lesson, or <code>null</code> if a matching request lesson could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson fetchBylessonsBasedOnDate_Last(
		java.util.Date createdDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the request lessons before and after the current request lesson in the ordered set where createdDate = &#63;.
	*
	* @param requestLessonId the primary key of the current request lesson
	* @param createdDate the created date
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next request lesson
	* @throws com.nyu.NoSuchRequestLessonException if a request lesson with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson[] findBylessonsBasedOnDate_PrevAndNext(
		long requestLessonId, java.util.Date createdDate,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchRequestLessonException;

	/**
	* Removes all the request lessons where createdDate = &#63; from the database.
	*
	* @param createdDate the created date
	* @throws SystemException if a system exception occurred
	*/
	public void removeBylessonsBasedOnDate(java.util.Date createdDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of request lessons where createdDate = &#63;.
	*
	* @param createdDate the created date
	* @return the number of matching request lessons
	* @throws SystemException if a system exception occurred
	*/
	public int countBylessonsBasedOnDate(java.util.Date createdDate)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the request lesson in the entity cache if it is enabled.
	*
	* @param requestLesson the request lesson
	*/
	public void cacheResult(com.nyu.model.RequestLesson requestLesson);

	/**
	* Caches the request lessons in the entity cache if it is enabled.
	*
	* @param requestLessons the request lessons
	*/
	public void cacheResult(
		java.util.List<com.nyu.model.RequestLesson> requestLessons);

	/**
	* Creates a new request lesson with the primary key. Does not add the request lesson to the database.
	*
	* @param requestLessonId the primary key for the new request lesson
	* @return the new request lesson
	*/
	public com.nyu.model.RequestLesson create(long requestLessonId);

	/**
	* Removes the request lesson with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param requestLessonId the primary key of the request lesson
	* @return the request lesson that was removed
	* @throws com.nyu.NoSuchRequestLessonException if a request lesson with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson remove(long requestLessonId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchRequestLessonException;

	public com.nyu.model.RequestLesson updateImpl(
		com.nyu.model.RequestLesson requestLesson)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the request lesson with the primary key or throws a {@link com.nyu.NoSuchRequestLessonException} if it could not be found.
	*
	* @param requestLessonId the primary key of the request lesson
	* @return the request lesson
	* @throws com.nyu.NoSuchRequestLessonException if a request lesson with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson findByPrimaryKey(long requestLessonId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchRequestLessonException;

	/**
	* Returns the request lesson with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param requestLessonId the primary key of the request lesson
	* @return the request lesson, or <code>null</code> if a request lesson with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.RequestLesson fetchByPrimaryKey(long requestLessonId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the request lessons.
	*
	* @return the request lessons
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.RequestLesson> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the request lessons.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.nyu.model.impl.RequestLessonModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of request lessons
	* @param end the upper bound of the range of request lessons (not inclusive)
	* @return the range of request lessons
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.RequestLesson> findAll(int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the request lessons.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.nyu.model.impl.RequestLessonModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of request lessons
	* @param end the upper bound of the range of request lessons (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of request lessons
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.RequestLesson> findAll(int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the request lessons from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of request lessons.
	*
	* @return the number of request lessons
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}