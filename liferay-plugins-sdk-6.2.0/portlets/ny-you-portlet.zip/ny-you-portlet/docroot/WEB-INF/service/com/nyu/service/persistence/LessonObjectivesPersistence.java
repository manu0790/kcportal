/**
 * Copyright (c) 2000-2013 Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.nyu.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.nyu.model.LessonObjectives;

/**
 * The persistence interface for the lesson objectives service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Allwins Rajaiah
 * @see LessonObjectivesPersistenceImpl
 * @see LessonObjectivesUtil
 * @generated
 */
public interface LessonObjectivesPersistence extends BasePersistence<LessonObjectives> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link LessonObjectivesUtil} to access the lesson objectives persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the lesson objectiveses where lessonId = &#63;.
	*
	* @param lessonId the lesson ID
	* @return the matching lesson objectiveses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.LessonObjectives> findBylessonObjectivesList(
		long lessonId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the lesson objectiveses where lessonId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.nyu.model.impl.LessonObjectivesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param lessonId the lesson ID
	* @param start the lower bound of the range of lesson objectiveses
	* @param end the upper bound of the range of lesson objectiveses (not inclusive)
	* @return the range of matching lesson objectiveses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.LessonObjectives> findBylessonObjectivesList(
		long lessonId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the lesson objectiveses where lessonId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.nyu.model.impl.LessonObjectivesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param lessonId the lesson ID
	* @param start the lower bound of the range of lesson objectiveses
	* @param end the upper bound of the range of lesson objectiveses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching lesson objectiveses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.LessonObjectives> findBylessonObjectivesList(
		long lessonId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first lesson objectives in the ordered set where lessonId = &#63;.
	*
	* @param lessonId the lesson ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lesson objectives
	* @throws com.nyu.NoSuchLessonObjectivesException if a matching lesson objectives could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.LessonObjectives findBylessonObjectivesList_First(
		long lessonId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchLessonObjectivesException;

	/**
	* Returns the first lesson objectives in the ordered set where lessonId = &#63;.
	*
	* @param lessonId the lesson ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching lesson objectives, or <code>null</code> if a matching lesson objectives could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.LessonObjectives fetchBylessonObjectivesList_First(
		long lessonId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last lesson objectives in the ordered set where lessonId = &#63;.
	*
	* @param lessonId the lesson ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lesson objectives
	* @throws com.nyu.NoSuchLessonObjectivesException if a matching lesson objectives could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.LessonObjectives findBylessonObjectivesList_Last(
		long lessonId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchLessonObjectivesException;

	/**
	* Returns the last lesson objectives in the ordered set where lessonId = &#63;.
	*
	* @param lessonId the lesson ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching lesson objectives, or <code>null</code> if a matching lesson objectives could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.LessonObjectives fetchBylessonObjectivesList_Last(
		long lessonId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the lesson objectiveses before and after the current lesson objectives in the ordered set where lessonId = &#63;.
	*
	* @param id the primary key of the current lesson objectives
	* @param lessonId the lesson ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next lesson objectives
	* @throws com.nyu.NoSuchLessonObjectivesException if a lesson objectives with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.LessonObjectives[] findBylessonObjectivesList_PrevAndNext(
		long id, long lessonId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchLessonObjectivesException;

	/**
	* Removes all the lesson objectiveses where lessonId = &#63; from the database.
	*
	* @param lessonId the lesson ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeBylessonObjectivesList(long lessonId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of lesson objectiveses where lessonId = &#63;.
	*
	* @param lessonId the lesson ID
	* @return the number of matching lesson objectiveses
	* @throws SystemException if a system exception occurred
	*/
	public int countBylessonObjectivesList(long lessonId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the lesson objectives in the entity cache if it is enabled.
	*
	* @param lessonObjectives the lesson objectives
	*/
	public void cacheResult(com.nyu.model.LessonObjectives lessonObjectives);

	/**
	* Caches the lesson objectiveses in the entity cache if it is enabled.
	*
	* @param lessonObjectiveses the lesson objectiveses
	*/
	public void cacheResult(
		java.util.List<com.nyu.model.LessonObjectives> lessonObjectiveses);

	/**
	* Creates a new lesson objectives with the primary key. Does not add the lesson objectives to the database.
	*
	* @param id the primary key for the new lesson objectives
	* @return the new lesson objectives
	*/
	public com.nyu.model.LessonObjectives create(long id);

	/**
	* Removes the lesson objectives with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param id the primary key of the lesson objectives
	* @return the lesson objectives that was removed
	* @throws com.nyu.NoSuchLessonObjectivesException if a lesson objectives with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.LessonObjectives remove(long id)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchLessonObjectivesException;

	public com.nyu.model.LessonObjectives updateImpl(
		com.nyu.model.LessonObjectives lessonObjectives)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the lesson objectives with the primary key or throws a {@link com.nyu.NoSuchLessonObjectivesException} if it could not be found.
	*
	* @param id the primary key of the lesson objectives
	* @return the lesson objectives
	* @throws com.nyu.NoSuchLessonObjectivesException if a lesson objectives with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.LessonObjectives findByPrimaryKey(long id)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.nyu.NoSuchLessonObjectivesException;

	/**
	* Returns the lesson objectives with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param id the primary key of the lesson objectives
	* @return the lesson objectives, or <code>null</code> if a lesson objectives with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.nyu.model.LessonObjectives fetchByPrimaryKey(long id)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the lesson objectiveses.
	*
	* @return the lesson objectiveses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.LessonObjectives> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the lesson objectiveses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.nyu.model.impl.LessonObjectivesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of lesson objectiveses
	* @param end the upper bound of the range of lesson objectiveses (not inclusive)
	* @return the range of lesson objectiveses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.LessonObjectives> findAll(int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the lesson objectiveses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.nyu.model.impl.LessonObjectivesModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of lesson objectiveses
	* @param end the upper bound of the range of lesson objectiveses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of lesson objectiveses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.nyu.model.LessonObjectives> findAll(int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the lesson objectiveses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of lesson objectiveses.
	*
	* @return the number of lesson objectiveses
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}